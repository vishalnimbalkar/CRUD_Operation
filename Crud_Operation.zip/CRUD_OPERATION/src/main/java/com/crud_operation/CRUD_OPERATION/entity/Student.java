package com.crud_operation.CRUD_OPERATION.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	private int id;
	private String fname;
	private String lname;
	private double marks;
	private int passout_year;
	
	public Student() {
		super();
	}

	public Student(int id, String fname, String lname, double marks, int passout_year) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.marks = marks;
		this.passout_year = passout_year;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public int getPassout_year() {
		return passout_year;
	}

	public void setPassout_year(int passout_year) {
		this.passout_year = passout_year;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", fname=" + fname + ", lname=" + lname + ", marks=" + marks + ", passout_year="
				+ passout_year + "]";
	}
	
	
	
}
