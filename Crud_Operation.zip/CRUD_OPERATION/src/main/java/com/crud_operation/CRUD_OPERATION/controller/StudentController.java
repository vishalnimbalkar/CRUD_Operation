package com.crud_operation.CRUD_OPERATION.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud_operation.CRUD_OPERATION.entity.Student;
import com.crud_operation.CRUD_OPERATION.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	
	private StudentService studentService;
	
	@Autowired
	StudentController(StudentService studentService){
		this.studentService= studentService;
	}

	//fetch all data from student table
	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent() {
		return this.studentService.getAllStudent();
	}
	
	//add student in the student table
	@PostMapping("/addStudent")
	public Student addStudent(@RequestBody Student student) {
		return this.studentService.addStudent(student);
	}
	
	//update student data in the student table
	@PutMapping("/updateStudent")
	public Student updateStudent(@RequestBody Student student) {
		return this.studentService.updateStudent(student);
	}
	
	//delete student from the student table
	@DeleteMapping("/deleteStudent/{id}")
	public Student deleteStudent(@PathVariable int id) {
		return this.studentService.deleteStudent(id);
	}
}
