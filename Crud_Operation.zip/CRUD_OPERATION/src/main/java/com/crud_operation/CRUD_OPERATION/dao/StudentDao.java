package com.crud_operation.CRUD_OPERATION.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.crud_operation.CRUD_OPERATION.entity.Student;

@Repository
public class StudentDao {
	
private SessionFactory sessionFactory;
	
	@Autowired
	StudentDao(SessionFactory sessionFactory){
		this.sessionFactory= sessionFactory;
	}

	public List<Student> getAllStudent() {
		Session session=sessionFactory.openSession();
		Criteria cr=session.createCriteria(Student.class);
		List<Student> list=cr.list();
		session.close();
		return list;
	}

	public Student addStudent(Student student) {
		Session session=sessionFactory.openSession();
		Transaction tra=session.beginTransaction();
		session.save(student);
		tra.commit();
		session.close();
		return student;
	}

	public Student updateStudent(Student student) {
		Session session=sessionFactory.openSession();
		Transaction tra=session.beginTransaction();
		session.update(student);
		tra.commit();
		session.close();
		return student;
	}

	public Student deleteStudent(int id) {
		Session session=sessionFactory.openSession();
		Transaction tra=session.beginTransaction();
		Student student=session.get(Student.class, id);
		session.delete(student);
		tra.commit();
		session.close();
		return student;
	}

}
