package com.crud_operation.CRUD_OPERATION.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud_operation.CRUD_OPERATION.dao.StudentDao;
import com.crud_operation.CRUD_OPERATION.entity.Student;

@Service
public class StudentService {

	private StudentDao studentDao;
	
	@Autowired
	StudentService(StudentDao studentDao){
		this.studentDao= studentDao;
	}
	
	public List<Student> getAllStudent() {
		return this.studentDao.getAllStudent();
	}

	public Student addStudent(Student student) {
		return this.studentDao.addStudent(student);
	}

	public Student updateStudent(Student student) {
		return this.studentDao.updateStudent(student);
	}

	public Student deleteStudent(int id) {
		return this.studentDao.deleteStudent(id);
	}

}
